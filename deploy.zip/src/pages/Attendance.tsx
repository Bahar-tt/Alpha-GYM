import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export async function getServerSideProps() {
  return { props: {} };
}
import FeatureLockedScreen from '../components/FeatureLockedScreen';
import {
  Fingerprint,
  Clock,
  ClipboardCheck,
  CalendarCheck2,
  UserCheck,
  LineChart,
  ShieldCheck,
} from 'lucide-react';

const attendanceBenefits = [
  { icon: Fingerprint, text: 'ورود و خروج خودکار با یک لمس انگشت — بدون ورود دستی' },
  { icon: Clock, text: 'ثبت دقیق زمان ورود و خروج هر عضو' },
  { icon: UserCheck, text: 'تشخیص خودکار اعضای منقضی‌شده یا غیرفعال هنگام ورود' },
  { icon: CalendarCheck2, text: 'حذف خطا و اختلاف در محاسبه جلسات مصرفی' },
  { icon: LineChart, text: 'گزارش لحظه‌ای حضور، غیاب و تاخیرها' },
  { icon: ClipboardCheck, text: 'استعلام سریع وضعیت هر عضو با جستجوی کد عضویت' },
];

export default function Attendance() {
  const { hasFeature } = useAuth();
  const navigate = useNavigate();

  if (!hasFeature('attendance')) {
    return (
      <FeatureLockedScreen
        icon={Fingerprint}
        title="حضور و غیاب هوشمند با اسکنر انگشت"
        description="کنترل دقیق ورود و خروج اعضا با یک لمس انگشت؛ ثبت خودکار زمان، مدیریت جلسات مصرفی و گزارش تاخیرها — همه در یک پنل یکپارچه، بدون ورود دستی و بدون خطا."
        benefits={attendanceBenefits}
        activationNote="ارتباط پنل با دستگاه اسکنر انگشت باشگاه با اشتراک ماهانه + هزینه راه‌اندازی در پکیج «مدیریت هوشمند» انجام می‌شود."
        onBack={() => navigate('/dashboard')}
      />
    );
  }

  return (
    <div className="space-y-6 animate-fade-in" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Fingerprint className="text-gold-400" size={26} />
            حضور و غیاب با اسکنر انگشت
          </h1>
          <p className="text-gray-500 text-sm mt-1">ثبت و مدیریت ورود و خروج اعضا</p>
        </div>
      </div>
      <div className="glass-card p-8 flex flex-col items-center text-center">
        <ShieldCheck className="text-gold-400 mb-3" size={32} />
        <p className="text-gray-400">در حال آماده‌سازی...</p>
      </div>
    </div>
  );
}
