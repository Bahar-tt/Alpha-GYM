declare module 'jalaali-js';
